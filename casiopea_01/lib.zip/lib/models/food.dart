class Food {
  String nama;
  String gambar;
  String kategori;
  int harga;
  int stok;

  Food(
    {required this.nama,
    required this.gambar,
    required this.kategori,
    required this.harga,
    required this.stok,
    }
  );
}
